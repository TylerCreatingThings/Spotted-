package ca.wlu.fark3230_a4;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;


public class MainActivity extends AppCompatActivity
        implements CardListFragment.OnListSelectedListener{

    private static final int ADD_CARD_CONSTANT = 1;
    private static final String SAVE_QUESTION = "QUESTION";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("Main", "onCreate");
        if (savedInstanceState != null) {
            Log.d("Main", "savedInstanceState Not Empty");

            //get new card here, input it into the deck.


            return;
        }
        if(savedInstanceState==null) {
            if (findViewById(R.id.fragment_container) != null) {
                Log.d("Main", "ListFragment Start");
                CardListFragment firstFragment = new CardListFragment();
                firstFragment.setArguments(getIntent().getExtras());
                getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, firstFragment).commit();
                Log.d("Main", "ListFragment Added");
            } else if (findViewById(R.id.list_fragment) != null) {
                CardListFragment firstFragment = new CardListFragment();
                firstFragment.setArguments(getIntent().getExtras());
                getSupportFragmentManager().beginTransaction().add(R.id.list_fragment, firstFragment).commit();
            }
        }

    }


    @Override
    public void onBackPressed(){
        int theBackStackCount = getSupportFragmentManager().getBackStackEntryCount();

        if(theBackStackCount > 0){
            getSupportFragmentManager().popBackStack();
        }
        else{
            super.onBackPressed();
        }
    }

    public void onDetailSelected(int position, Card passedCard){
        Log.d("Main", "Detail Fragment Added");
        if(findViewById(R.id.detail_fragment) != null){
            CardDetailFragment newFragment = new CardDetailFragment();
            Bundle args = new Bundle();
            args.putInt(CardDetailFragment.ARG_POSITION,position);
            args.putParcelable(CardDetailFragment.CARD,passedCard);
            newFragment.setArguments(args);
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.detail_fragment,newFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        }
        else if(findViewById(R.id.fragment_container)!=null){
            CardDetailFragment newFragment = new CardDetailFragment();
            Bundle args = new Bundle();
            args.putInt(CardDetailFragment.ARG_POSITION,position);
            args.putParcelable(CardDetailFragment.CARD,passedCard);
            newFragment.setArguments(args);
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container,newFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        }
    }

    public static Intent newIntent(Context packageContext,String question){
        Intent intent = new Intent(packageContext,MainActivity.class);
        intent.putExtra(SAVE_QUESTION,question);
        return intent;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar_menu,menu);
        return true;
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        Log.d("Main","onSaveInstanceState");
    }

}
