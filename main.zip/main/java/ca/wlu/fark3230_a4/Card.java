package ca.wlu.fark3230_a4;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.UUID;

/**
 * Created by Tyler on 2017-09-19.
 */

public class Card implements Parcelable
{
    private String mImage;
    private String mQuestion;
    private String mAnswer;
    private String mId;


    public Card(String theImage, String theQuestion, String theAnswer){

        mImage = theImage;
        mQuestion = theQuestion;
        mAnswer = theAnswer;
        mId = UUID.randomUUID().toString();
    }

    public Card(String uuid, String theImage, String theQuestion, String theAnswer){
        mId=uuid;
        mImage = theImage;
        mQuestion = theQuestion;
        mAnswer = theAnswer;
    }

    public String getUUID() {return mId;}

    public String getImage(){
        return mImage;
    }

    public String getQuestion(){
        return mQuestion;
    }

    public String getAnswer(){
        return mAnswer;
    }

    @Override
    public String toString(){
        return mImage+mQuestion+mAnswer;
    }

    public Card(Parcel in){
        this.mImage = in.readString();
        this.mQuestion = in.readString();
        this.mAnswer = in.readString();
        this.mId = in.readString();
    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags){
        dest.writeString(mImage);
        dest.writeString(mQuestion);
        dest.writeString(mAnswer);
        dest.writeString(mId);
    }

    public static final Parcelable.Creator<Card> CREATOR = new Parcelable.Creator<Card>(){
        public Card createFromParcel(Parcel in){
            return new Card(in);
        }

        @Override
        public Card[] newArray(int i) {
            return new Card[i];
        }
    };
}

