package ca.wlu.fark3230_a4.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import ca.wlu.fark3230_a4.database.CardDbSchema.CardTable;

/**
 * Created by Tyler on 2017-11-05.
 */

public class CardBaseHelper extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "cardBase.db";

    public CardBaseHelper(Context context){
        super(context,DATABASE_NAME,null,VERSION);
        Log.d("CardBaseHelper","Creating CardBaseHelper");
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        Log.d("CardBaseHelper","Creating database");
        db.execSQL("CREATE TABLE " + CardTable.NAME + "(" +
                CardTable.Cols.UUID + " varchar primary key, " +
                CardTable.Cols.QUESTION + ", " +
                CardTable.Cols.ANSWER + ", " +
                CardTable.Cols.IMAGE + ")"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }
}
