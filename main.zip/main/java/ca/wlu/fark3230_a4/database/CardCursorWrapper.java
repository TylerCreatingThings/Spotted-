package ca.wlu.fark3230_a4.database;

import android.database.Cursor;
import android.database.CursorWrapper;
import ca.wlu.fark3230_a4.Card;
import ca.wlu.fark3230_a4.database.CardDbSchema.CardTable;

/**
 * Created by Tyler on 2017-11-05.
 */

public class CardCursorWrapper extends CursorWrapper {

    public CardCursorWrapper(Cursor cursor){
        super(cursor);
    }

    public Card getCard(){

        String question = getString(getColumnIndex(CardTable.Cols.QUESTION));
        String answer = getString(getColumnIndex(CardTable.Cols.ANSWER));
        String image = getString(getColumnIndex(CardTable.Cols.IMAGE));
        String uuidString = getString(getColumnIndex(CardTable.Cols.UUID));

        Card newCard = new Card(uuidString,image,question,answer);

        return newCard;
    }

}
