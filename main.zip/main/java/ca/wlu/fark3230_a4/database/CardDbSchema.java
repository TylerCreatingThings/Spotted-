package ca.wlu.fark3230_a4.database;

/**
 * Created by Tyler on 2017-11-05.
 */

public class CardDbSchema {
    public static final class CardTable {
        public static final String NAME = "cards";


        public static final class Cols {
            public static final String UUID = "uuid";
            public static final String QUESTION = "question";
            public static final String ANSWER = "answer";
            public static final String IMAGE = "image";
        }
    }
}
