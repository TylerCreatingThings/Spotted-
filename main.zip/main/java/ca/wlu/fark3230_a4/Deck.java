package ca.wlu.fark3230_a4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.util.ArrayList;

import ca.wlu.fark3230_a4.database.CardBaseHelper;
import ca.wlu.fark3230_a4.database.CardCursorWrapper;
import ca.wlu.fark3230_a4.database.CardDbSchema.CardTable;

/**
 * Created by Tyler on 2017-09-19.
 */

public class Deck implements Parcelable{
    private ArrayList<Card> mDeckOfCards;
    private int mCount;
    private static Deck sDeckofCards;
    private SQLiteDatabase mDatabase;
    private Context mContext;

    public Deck(Context context){
        mContext = context;
        mContext = mContext.getApplicationContext();
        Log.d("CardBaseHelper","Creating Deck");
        mDatabase = new CardBaseHelper(mContext).getWritableDatabase();
        Log.d("CardBaseHelper","got the writable database.");
        mCount=0;
        Log.d("Deck", "onCreate");

        mDeckOfCards = getDeck();
        if(mDeckOfCards.size()<1) {
            initializeDeck();
        }
    }

    private static ContentValues getContentValues(Card card){
        ContentValues values = new ContentValues();
        values.put(CardTable.Cols.UUID, card.getUUID());
        values.put(CardTable.Cols.QUESTION, card.getQuestion());
        values.put(CardTable.Cols.ANSWER, card.getAnswer());
        values.put(CardTable.Cols.IMAGE, card.getImage());
        return values;
    }



    public Card getCard(String uuid){
        CardCursorWrapper cursor = queryCards(CardTable.Cols.UUID + "= ?",
                new String[] {uuid});

        try
        {
            if(cursor.getCount() ==  0){
                return null;
            }
            cursor.moveToFirst();
            return cursor.getCard();
        }finally
        {
            cursor.close();
        }
    }

    public boolean isCardInDatabase(String question){
        CardCursorWrapper cursor = queryCards(CardTable.Cols.QUESTION + "= ?",
                new String[] {question});

        try
        {
            if(cursor.getCount() ==  0){
                return false;
            }
            cursor.moveToFirst();
            return true;
        }finally
        {
            cursor.close();
        }
    }

    public ArrayList<Card> getDeck(){

        ArrayList<Card> cards = new ArrayList<Card>();
        CardCursorWrapper cursor = queryCards(null,null);

        try{
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                cards.add(cursor.getCard());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }
        return cards;
    }


    public void initializeDeck(){
        Card cardOne = new Card("color_wheel","What color is my hair?","Brown");
        Card cardTwo = new Card("classes","What is my favourite class?","CP470");
        Card cardThree = new Card("coffee","What is my favourite programming language?","Java");
        Card cardFour = new Card("eu","How do I develop such awesome icons?","Go on a trip to europe");
        Card cardFive = new Card("slss","Which high school did I go to?","Stephen Lewis Secondary School");

        add(cardOne);
        add(cardTwo);
        add(cardThree);
        add(cardFour);
        add(cardFive);
    }

    public void add(Card userCard){

        if(isCardInDatabase(userCard.getQuestion()) == false) {
            Log.d("Deck","inserted card.");
            ContentValues values = getContentValues(userCard);
            mDatabase.insert(CardTable.NAME, null, values);
        }
    }

    private CardCursorWrapper queryCards(String whereClause, String[] whereArgs){
        Cursor cursor = mDatabase.query(CardTable.NAME,
                                        null,
                                        whereClause,
                                        whereArgs,
                                        null,
                                        null,
                                        null);
        return new CardCursorWrapper(cursor);
    }

    public void updateCard(Card card){
        String uuidString = card.getUUID();
        ContentValues values = getContentValues(card);
        mDatabase.update(CardTable.NAME, values,CardTable.Cols.UUID + "= ?", new String[] {uuidString});
    }


    public void deleteUser(String uuid)
    {
        Log.d("Deck","Deleting now.");
        try
        {
            mDatabase.delete(CardTable.NAME, CardTable.Cols.UUID + "= ?", new String[] {uuid});
            Log.d("Deck","Deleted.");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }


    public Deck(Parcel in){
        this.mCount=in.readInt();
    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags){
        dest.writeInt(mCount);
    }

    public static final Parcelable.Creator<Deck> CREATOR = new Parcelable.Creator<Deck>(){
        public Deck createFromParcel(Parcel in){
            return new Deck(in);
        }

        @Override
        public Deck[] newArray(int i) {
            return new Deck[i];
        }


    };

}
