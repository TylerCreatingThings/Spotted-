package ca.wlu.fark3230_a4;

import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.NavUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Tyler on 2017-10-22.
 */

public class CardDetailFragment extends Fragment {
    public final static String ARG_POSITION = "pos";
    public final static String CARD = "card";
    private int mCurrentPosition = -1;
    private Card currentCard;
    private static final int ADD_CARD_CONSTANT = 1;

    @Override
    public void onStart(){
        super.onStart();
        Log.d("CardDetailFragment","onStart");
        Bundle args = getArguments();
        if(args != null){
            currentCard = args.getParcelable(CARD);
            updateDetailView(args.getInt(ARG_POSITION),currentCard);

        }
    }


    public void updateDetailView(int position, Card curCard){
        //take position
        setDetailImage(currentCard.getImage());
        setDetailAnswer(currentCard.getAnswer());

    }

    private void setDetailImage(String imageName){
        Resources res = getResources();
        int resourceId = res.getIdentifier(imageName, "drawable", getActivity().getPackageName());
        ImageView imageView = (ImageView) getActivity().findViewById(R.id.ivDetailImage);
        imageView.setImageResource(resourceId);
    }

    private void setDetailAnswer(String answer){
        TextView tvQuestion = (TextView) getActivity().findViewById(R.id.tvDetailAnswer);
        tvQuestion.setText(answer);
    }

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        Log.d("CardDetailFragment","onCreateView");
        View v = inflater.inflate(R.layout.card_detail_fragment, container, false);

        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.HONEYCOMB) {
            if (NavUtils.getParentActivityName(getActivity()) != null)
            {
                getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }

        return v;
    }

    @Override
    public void onStop(){
        super.onStop();
        Log.d("CardDetailFragment","onStop");
    }


}
