package ca.wlu.fark3230_a4;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;


public class CardListFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private CardAdapter mAdapter;
    private static final int ADD_CARD_CONSTANT = 1;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        Log.d("CardListFragment", "onCreate");
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        Log.d("CardListFragment", "onCreateView");
        View v  = inflater.inflate(R.layout.card_recycleview_fragment, container, false);


        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.HONEYCOMB) {
            if (NavUtils.getParentActivityName(getActivity()) != null)
            {
                getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }


        Log.d("CardListFragment", "Inflated recycleview layout");
        //the recycle view should use, the card_item_fragment.

        mRecyclerView = (RecyclerView) v.findViewById(R.id.card_recycle_view);
        Log.d("CardListFragment", "Setting Layout Manager");
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        updateUI();

        ItemTouchHelper.SimpleCallback simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(final RecyclerView.ViewHolder viewHolder, int direction) {
                final int position = viewHolder.getAdapterPosition(); //get position which is swipe

                if (direction == ItemTouchHelper.LEFT) {    //if swipe left

                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity()); //alert for confirm to delete
                    builder.setMessage("Are you sure to delete?");    //set message

                    builder.setPositiveButton("REMOVE", new DialogInterface.OnClickListener() { //when click on DELETE
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                               //item removed from recylcerview
                            Deck deck = new Deck(getContext());
                            ArrayList<Card> deckList = deck.getDeck();
                            Card deleteCard = deckList.get(position);
                            deck.deleteUser(deleteCard.getUUID());
                            deckList.remove(position);

                            if(deckList.size() >1) {
                                mAdapter.setAdapterList(deckList);
                                mAdapter.notifyDataSetChanged();
                            }
                            else{
                                mAdapter.notifyItemRemoved(position);
                            }
                            return;
                        }
                    }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {  //not removing items if cancel is done
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            mAdapter.notifyItemRemoved(position + 1);    //notifies the RecyclerView Adapter that data in adapter has been removed at a particular position.
                            mAdapter.notifyItemRangeChanged(position, mAdapter.getItemCount());   //notifies the RecyclerView Adapter that positions of element in adapter has been changed from position(removed element index to end of list), please update it.
                            return;
                        }
                    }).show();  //show alert dialog
                }
            }

            ;
        };
            ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
        itemTouchHelper.attachToRecyclerView(mRecyclerView); //set swipe to recylcerview

        return v;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        //Handle item selected
        switch(item.getItemId()){
            case R.id.new_card:
                Log.d("Main", "Add button pressed");
                Intent startAddActivity = new Intent(getActivity(), activity_add_card.class);
                startActivityForResult(startAddActivity, ADD_CARD_CONSTANT);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        Log.d("CardListDetail","onActivityResult");
        if(resultCode != Activity.RESULT_OK){
            Log.d("Main","Didn't Work");
            return;
        }
        if(requestCode == ADD_CARD_CONSTANT){
            if(data == null){
                Log.d("Main","Didn't work again");
                return;
            }

            Card newCard = (Card) data.getParcelableExtra(activity_add_card.ADD_CARD_STRING);
            Log.d("Main",newCard.toString());
            Deck currentDeck = new Deck(getContext());
            currentDeck.add(newCard);
            updateUI();
        }
    }
    private void updateUI(){
        Deck currentDeck = new Deck(getContext());
        ArrayList<Card> cards = currentDeck.getDeck();
        Log.d("CardListFragment", "Creating Adapter");
        Log.d("CardListFragment",cards.toString());
        mAdapter = new CardAdapter(cards);
        Log.d("CardListFragment", "Setting RecycleView Adapter");
        mRecyclerView.setAdapter(mAdapter);
        Log.d("CardListFragment", "Done Setting Adapter");
    }





    private class CardHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private ImageView mCardImage;
        private TextView mQuestionText;
        private Card mCard;


        public CardHolder(LayoutInflater inflater, ViewGroup parent){
            super(inflater.inflate(R.layout.card_item_fragment,parent,false));
            itemView.setOnClickListener(this);
            Log.d("CardListFragment", "Create CardHolder");
            mCardImage = (ImageView) itemView.findViewById(R.id.ivImageHolder);
            mQuestionText = (TextView) itemView.findViewById(R.id.tvQuestionHolder);
        }

        @Override
        public void onClick(View v){
            //Do something here. Start the detail fragment.
            mCallBack.onDetailSelected(0,mCard);
        }

        public void bind(Card curCard){
            Log.d("CardListFragment", "bind");
            mCard = curCard;
            Resources res = getResources();
            int resourceId = 0;
            resourceId = res.getIdentifier(curCard.getImage(), "drawable", getActivity().getPackageName());

            mCardImage.setImageResource(resourceId);
            mQuestionText.setText(curCard.getQuestion());
        }


    }

    private class CardAdapter extends RecyclerView.Adapter<CardHolder>{
        private ArrayList<Card> mDeck;

        public CardAdapter(ArrayList<Card> myDeck){
            Log.d("CardListFragment", "Initializing Adapter");
            this.mDeck=myDeck;
        }

        @Override
        public CardHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            Log.d("CardListFragment", "onCreateViewHolder");
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new CardHolder(layoutInflater,parent);
        }

        public void setAdapterList(ArrayList<Card> deck){
            this.mDeck = deck;
        }



        @Override
        public void onBindViewHolder(CardHolder holder, int position) {
            Log.d("CardListFragment", "onBindViewHolder");
            Card curCard = mDeck.get(position);
            holder.bind(curCard);
        }


        @Override
        public int getItemCount() {
            return mDeck.size();
        }
    }

    OnListSelectedListener mCallBack;

    public interface OnListSelectedListener{
        public void onDetailSelected(int position,Card card);
    }

    @Override
    public void onAttach(Activity activity){
        super.onAttach(activity);
        Log.d("CardListFragment","onAttach");
        try
        {
            mCallBack = (OnListSelectedListener) activity;
        }
        catch(ClassCastException e){
            throw new ClassCastException(activity.toString() + "must implement OnListSelectedListener.");
        }
    }


}