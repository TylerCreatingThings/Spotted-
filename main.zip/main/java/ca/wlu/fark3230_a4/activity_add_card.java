package ca.wlu.fark3230_a4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class activity_add_card extends AppCompatActivity {
    public static final String ADD_CARD_STRING = "ADD_CARD";
    private Card newCard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_card);
    }



    public void addNewCard(View v){
        Log.d("Card","You pressed the add button");
        Toast.makeText(this,"Added New Card.", Toast.LENGTH_LONG).show();
        EditText getQuestion = (EditText) findViewById(R.id.etNewQuestion);
        EditText getAnswer = (EditText) findViewById(R.id.etNewAnswer);
        EditText getImage = (EditText) findViewById(R.id.etNewImage);
        Log.d("Card","Creating the card.");
        Log.d("Card",getImage.getText().toString());
        newCard = new Card(getImage.getText().toString(),getQuestion.getText().toString(),getAnswer.getText().toString());
        Log.d("Card",newCard.toString());

    }
    @Override
    public void onBackPressed(){
        if(newCard != null) {
            Intent sendData = new Intent();
            sendData.putExtra(activity_add_card.ADD_CARD_STRING, newCard);
            setResult(activity_add_card.RESULT_OK, sendData);
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Card","Sending the data back.");
    }
}
